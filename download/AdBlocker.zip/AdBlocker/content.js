// content.js
console.log("AdShield 廣告清掃機器人 v5.6 - Yahoo新聞特別強化版");

// 廣告選擇器
const adSelectors = [
    // --- 1. Yahoo 新聞專用 (針對妳提供的原始碼) ---
    '[id^="sda-"]',             // 殺手鐧：抓取所有以 sda- 開頭的 ID (包含 top, mid, btm, moments)
    '.stream-taboola-ad',       // 新聞列表中的 Taboola 廣告卡片
    '[id^="mkt-iframe"]',       // 插入在文章中間的行銷 iframe
    '.text-gandalf',            // "廣告" 文字標籤
    '.bg-toast-background',     // 廣告背景容器

    // --- 2. 針對 ExoClick ---
    'div[class*="exo-native-widget"]',
    'video[id^="exo-video-"]',
    
    // --- 3. Google AdSense ---
    '.adsbygoogle',
    '#google_image_div',
    '#google_ads_iframe',
    'iframe[src*="googleads"]',
    
    // --- 4. 通用補強 ---
    'div[id*="ad_unit"]',
    'div[class*="ad-container"]'
];

function removeAds() {
    if (adSelectors.length === 0) return;

    const selectorString = adSelectors.join(', ');
    const ads = document.querySelectorAll(selectorString);

    ads.forEach(ad => {
        // 【重要】白名單防護：若是學校輪播圖或導覽列，絕對不殺
        if (isSafeContent(ad)) {
            // console.log("略過安全內容:", ad);
            return; 
        }

        // --- 策略 A: Yahoo 特殊處理 (sda 系列) ---
        // 妳提供的原始碼顯示 Yahoo 用 sda-top-center, sda-mid-right 等
        if (ad.id && ad.id.startsWith('sda-')) {
            // 這些通常包在好幾層 div 裡，直接殺掉這個元素通常就乾淨了
            // 如果它父層有個高度固定的空框，這行會讓它消失
            destroyElement(ad);
            
            // 順便檢查父層，如果是單純用來包廣告的 wrapper，也殺掉
            if (ad.parentElement && ad.parentElement.innerText.trim() === '廣告') {
                 destroyElement(ad.parentElement);
            }
        }

        // --- 策略 B: 針對 "廣告" 文字標籤 (text-gandalf) ---
        else if (ad.classList.contains('text-gandalf') || ad.innerText.trim() === '廣告') {
            // 往上找包著它的容器 (通常是 bg-toast-background 或父 div)
            const parent = ad.closest('.bg-toast-background') || ad.parentElement;
            if (parent && !isSafeContent(parent)) {
                destroyElement(parent);
            } else {
                destroyElement(ad);
            }
        }

        // --- 策略 C: 針對背景容器 ---
        else if (ad.classList.contains('bg-toast-background')) {
             destroyElement(ad);
        }

        // --- 策略 D: Taboola 與其他 ---
        else {
             destroyElement(ad);
        }
    });
}

// 【白名單檢測函式】(維持原樣，保護元智大學)
function isSafeContent(el) {
    if (!el) return false;

    // 1. 檢查 class 名稱
    const className = (el.className || '').toString().toLowerCase();
    const idName = (el.id || '').toString().toLowerCase();
    
    // 絕對安全的關鍵字
    if (className.includes('carousel') ||    // 保護輪播圖
        className.includes('navbar') ||      // 保護導覽列
        className.includes('menu') ||        // 保護選單
        el.tagName === 'HEADER' ||           // 保護頁首
        el.tagName === 'NAV')                // 保護導航區
    {
        return true; 
    }

    // 2. 往上找父層 (保護結構)
    if (el.closest('.carousel-inner') || el.closest('.navbar')) {
        return true;
    }

    return false;
}

// 毀滅元素的函式
function destroyElement(el) {
    if (!el) return;
    if (el.tagName === 'BODY' || el.tagName === 'HTML') return;

    el.style.setProperty('display', 'none', 'important');
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('height', '0px', 'important');
    el.style.setProperty('min-height', '0px', 'important'); 
    el.style.setProperty('margin', '0px', 'important');
    el.style.setProperty('padding', '0px', 'important');
    el.innerHTML = ''; 
}

// 執行清除
removeAds();

// 監聽動態載入
const observer = new MutationObserver((mutations) => {
    let shouldCheck = false;
    for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
            shouldCheck = true;
            break;
        }
    }
    if (shouldCheck) {
        removeAds();
    }
});
observer.observe(document.body, { childList: true, subtree: true });