// content.js
console.log("AdShield v33.0 - Yahoo Toast/Moments 補漏版");

const currentUrl = window.location.href;

//共通檢查
const globalCss = `
    .mobadsq, 
    .div_close_ads, 
    .div_adhost, 
    #baoziAdPopup,
    div[data-v-6f00f28b] { 
        display: none !important; 
        opacity: 0 !important; /*透明為0*/
        visibility: hidden !important; /*隱藏可見*/
        height: 0 !important;
        width: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        pointer-events: none !important; /* 讓滑鼠點不到 */
        z-index: -2147483648 !important; /* 設定到整數最小值，確保廣告被壓到最下面 */
        position: fixed !important; /*廣告丟到最邊邊的隱藏位*/
        top: -9999px !important; //同上
        left: -9999px !important; //同上
        clip-path: polygon(0 0, 0 0, 0 0); //將他裁剪成點，處理會偵測尺寸、位置的廣告)
    }

    .gg_728, .B1L, .B1R, 
    #defaultMAST-wrapper, #defaultMAST-sizer, #sda-top-center-iframe,
    .bg-toast-background, #sda-moments-iframe, .text-gandalf,
    .bg-dirty-seagull, div[id^="MON-1-Ad"] {
        display: none !important; /*以important最高指令行事，在沒被反偵測的時候直接不顯示廣告*/
    }
`;

//把上面那坨打包成css丟到head or html底下
const styleTag = document.createElement('style');
styleTag.textContent = globalCss;
(document.head || document.documentElement).appendChild(styleTag);

//除殘留div並維持原功能
if (currentUrl.includes('olevod') || currentUrl.includes('u68web5') || currentUrl.includes('manhuagui')) {
    setInterval(() => {
        document.querySelectorAll('.B1L, .B1R, .gg_728, ins.adsbyexoclick').forEach(el => el.remove());
        document.querySelectorAll('div[style*="width: 300px"]').forEach(el => el.remove());
		document.querySelectorAll('[class*="gg_950 jghf"], [class*="gg_950"]').forEach(el => el.remove());
    }, 500);
}

if (currentUrl.includes('yahoo') || currentUrl.includes('ettoday') || currentUrl.includes('chinatimes') || currentUrl.includes('ltn')
	|| currentUrl.includes('setn') || currentUrl.includes('nextapple')) {
    setInterval(() => {
    const NewsAd = document.querySelectorAll(`
		#defaultMAST-wrapper,
		#defaultMAST-sizer,
		div[id^="LREC-1-Ad"],
		#sda-moments-iframe,
		.bg-toast-background,
		.text-gandalf,
		div[id^="MON-1-Ad"],
		.bg-dirty-seagull,
		div[id^="sda"][id*="right-iframe"],
		[class*="gg_950"],
		div[id^="mrt-node-Col2-"][id*="-Ad"],
		div[id*="-Ad-Proxy"],
		div[id*="-ad-wrapper"],
		div[id*="-AdWrapper-Proxy"],
		div[id^="YDC-Lead"],
		[class*="D(n) desktop_D(b)!--miw960"],
		div[id*="sda-MAST"],
		div[class*="ad"][class*="with-placeholder"],
		
		
		//三立
		[id*="adsMedia"], 
        [id*="banner-video"], 
        [src*="ad.setn.com"],
        [id*="_ad"],
		[class*="_ad"],
		
		//蘋果
		[id*="headbanner"]
	`);
        NewsAd.forEach(el => el.remove());
		
    document.querySelectorAll('div[id^="ad-K"], div[id^="ad-BD"]').forEach(el => el.remove());
	document.querySelectorAll('[id*="bar_ad"], [class*="meta_ad"]').forEach(el => el.remove());
        // 圖片保護 (保持原樣)
    document.querySelectorAll('div[class*="Maw(220px)"], img').forEach(el => {
        el.style.display = 'block'; 
        el.style.visibility = 'visible';
    });
}, 1000);
}