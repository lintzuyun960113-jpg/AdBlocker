chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ enabled: true }, () => {
        updateBadge("ON");
    });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "toggleBlocking") {
        const isEnabled = request.enabled;
        if (isEnabled) {
            chrome.declarativeNetRequest.updateEnabledRulesets({
                enableRulesetIds: ["ruleset_1"] 
            }, () => {
                updateBadge("ON");
            });
        } else {
            chrome.declarativeNetRequest.updateEnabledRulesets({
                disableRulesetIds: ["ruleset_1"]
            }, () => {
                updateBadge("OFF");
            });
        }
    }
});

function updateBadge(text) {
    chrome.action.setBadgeText({ text: text });
    const color = text === "ON" ? "#4CAF50" : "#9E9E9E";
    chrome.action.setBadgeBackgroundColor({ color: color });
}