document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggle-btn');
  const statusText = document.getElementById('status-text');

  chrome.storage.local.get(['enabled'], (result) => {
    const isEnabled = result.enabled !== false; 
    updateUI(isEnabled);
  });

  toggleBtn.addEventListener('change', () => {
    const isEnabled = toggleBtn.checked;
    
    chrome.storage.local.set({ enabled: isEnabled }, () => {
        // 更新 UI
        updateUI(isEnabled);

        // 發送訊息給背景
        chrome.runtime.sendMessage({ 
          action: "toggleBlocking", 
          enabled: isEnabled 
        });

        // 強制重整網頁
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0] && tabs[0].id) {
                chrome.tabs.reload(tabs[0].id);
            }
        });
    });
  });

  function updateUI(enabled) {
    toggleBtn.checked = enabled;
    if (enabled) {
      statusText.textContent = "🛡️ 保護運作中";
      statusText.style.color = "#5BC0BE";
    } else {
      statusText.textContent = "⚠️ 保護已暫停";
      statusText.style.color = "#ff4444";
    }
  }
});