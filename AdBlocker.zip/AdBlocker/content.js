// content.js
console.log("AdShield 廣告清掃機器人 v4.0 - 容器獵殺版");

const adSelectors = [
    // --- 1. 妳剛剛提供的特定 ID 與 Class (優先處理) ---
    '#sda-moments-iframe',      // 這次截圖中的廣告 ID
    '.text-gandalf',            // 那個寫著 "廣告" 的小標籤 Class
    '.bg-toast-background',     // 包住整個廣告的外層容器
    
    // --- 2. Google & 常見廣告商 ---
    '.adsbygoogle',
    '#google_image_div',
    '#google_ads_iframe',
    'iframe[src*="google"]',
    'iframe[src*="ads"]',
    
    // --- 3. 通用關鍵字模糊比對 ---
    'div[class*="ad-"]',
    'div[class*="ads-"]',
    'div[class*="banner"]',
    'div[class*="sponsor"]',
    'div[id*="ad-"]',
    'div[id*="ads-"]',
    'div[id*="banner"]',
    'div[id*="sponsor"]',
    
    // --- 4. 之前抓到的規則 ---
    '#sda-top-center-iframe', 
    'div[class*="text-dolphin"]',
    'div[class*="exo-native-widget"]',
    'video[id^="exo-video-"]',
    'div[style*="width: 728px"]'
];

function removeAds() {
    const selectorString = adSelectors.join(', ');
    const ads = document.querySelectorAll(selectorString);

    ads.forEach(ad => {
        // --- 策略 A: 針對 "廣告" 文字標籤 (text-gandalf) ---
        // 如果這個元素是寫著「廣告」的標籤，我們要殺的是它的 "爸爸" (容器)
        if (ad.innerText.trim() === '廣告' || ad.classList.contains('text-gandalf')) {
            if (ad.parentElement) {
                // 殺掉父層 (那個 bg-toast-background)
                destroyElement(ad.parentElement);
            } else {
                destroyElement(ad);
            }
        }
        // --- 策略 B: 針對外層容器 (bg-toast-background) ---
        // 只要看到這個背景色容器，直接清除，不用問
        else if (ad.classList.contains('bg-toast-background')) {
             destroyElement(ad);
        }
        // --- 策略 C: 針對 iframe 內容 ---
        // 如果是剛被抓到的 sda-moments-iframe
        else if (ad.id === 'sda-moments-iframe' || ad.id === 'sda-top-center-iframe') {
             // 殺掉自己
             destroyElement(ad);
             // 順便檢查父層，如果父層高度很小或也是廣告容器，順便殺掉
             if(ad.parentElement && (ad.parentElement.offsetHeight < 300 || ad.parentElement.classList.contains('bg-toast-background'))) {
                 destroyElement(ad.parentElement);
             }
        }
        // --- 策略 D: 其他通用規則 ---
        else {
             destroyElement(ad);
        }
    });
}

// 毀滅元素的函式 (保持暴力隱藏)
function destroyElement(el) {
    if (!el) return;
    el.style.setProperty('display', 'none', 'important');
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('height', '0px', 'important');
    el.style.setProperty('min-height', '0px', 'important'); 
    el.style.setProperty('max-height', '0px', 'important');
    el.style.setProperty('margin', '0px', 'important');
    el.style.setProperty('padding', '0px', 'important');
    el.style.setProperty('overflow', 'hidden', 'important');
    el.innerHTML = ''; 
}

// 1. 執行清除
removeAds();

// 2. 監聽動態載入
const observer = new MutationObserver((mutations) => {
    let shouldCheck = false;
    for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
            shouldCheck = true;
            break;
        }
    }
    if (shouldCheck) {
        removeAds();
    }
});
observer.observe(document.body, { childList: true, subtree: true });